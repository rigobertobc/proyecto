<header class="main-header">

    <!-- Logo -->
    <a href="../Views/plantilla.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"> <b> <span style="color:black;"> RD </span> <span style="color:red;"> G </span> </b> </span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"> <img src="../Public/img/logo.png" height="50px" width="200px" /> </span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">

      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" >
        <span> <i class="fas fa-bars"></i> </span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

          <li class="user-menu">
            <a href="../salir.php">
              <span class="hidden-xs"> <i class="fas fa-sign-out-alt"></i>  <strong> Salir </strong> </span>
            </a>
          </li>

        </ul>
      </div>
    </nav>
  </header>
