drop database if exists rincondelgamer;
create database if not exists rincondelgamer;
use rincondelgamer;

create table rol(
	idRol int not null auto_increment primary key,
    nombre varchar(25) not null
);
alter table rol auto_increment=1;

insert into rol(nombre) values('Admin'),('Gamer');

create table usuario(
	idUsuario int not null auto_increment primary key,
    idRol int not null references rol(idRol),
    nombre varchar(30) not null,
    aPaterno varchar(20) not null,
    aMaterno varchar(20) null,
    fechaNacimiento date not null,
    genero int not null,
    telefono varchar(10) not null,
    correo varchar(25) not null,
    usuario varchar(20) not null,
    contrasenia varchar(100) not null,
    rutaFoto varchar(70) null,
    idUsuarioReferencia int null default 0,
    monedasReferencia int null default 0,
    totalMonedas int null default 0
);
alter table usuario auto_increment=1;

insert into usuario(idRol,nombre,aPaterno,aMaterno,fechaNacimiento,genero,telefono,correo,usuario,contrasenia,monedasReferencia)values(1,'Julio','Frausto','Morán','','','','','Admin','e3afed0047b08059d0fada10f400c1e5',0);

create table redSocial(
	idRedSocial int not null auto_increment primary key,
    nombre varchar(25) not null
);
alter table redSocial auto_increment=1;

create table redSocialUsuario(
	idUsuario int not null references usuario(idUsuario),
    idRedSocial int not null references redSocial(idRedSocial),
    nombreUsuarioEnRed varchar(50) not null,
    link varchar(100) null
);

create table plataforma(
	idPlataforma int signed not null auto_increment primary key,
    nombre varchar(25) not null
);
alter table plataforma auto_increment=1;

create table consola(
	idConsola int signed not null auto_increment primary key,
    idPlataforma int signed not null references plataforma(idPlataforma),
    nombre varchar(25) not null,
    numero varchar(5) not null,
    seriall varchar(20) null,
    costo int not null,
    premioMonedas int not null,
    costoMonedas int not null
);
alter table consola auto_increment=1;

create table juego(
	idJuego int not null auto_increment primary key,
    nombre varchar(20) not null,
    rutaFoto varchar(1000) not null
);
alter table juego auto_increment=1;

create table consolaJuego(
	idConsola int signed not null references consola(idConsola),
    idJuego int not null references juego(idJuego)
);

create table torneo(
	idTorneo int not null auto_increment primary key,
    idConsola int not null references consolaJuego(idConsola),
    idJuego int not null references consolaJuego(idJuego),
    titulo varchar(30) not null,
    fecha date not null,
    hora time not null,
    modalidad int not null,
    totalIntegrantesEquipo int not null,
    forma int not null,
    maximoEquipos int not null,
    descripcion varchar(150) not null,
    estatus int not null default 1,
    costo int not null
);
alter table torneo auto_increment=1;

create table premio(
	idPremio int not null auto_increment primary key,
    idTorneo int not null references torneo(idTorneo),
    posicion int not null,
    premio varchar(100) not null
);
alter table premio auto_increment=1;

create table equipoTorneo(
	idEquipo int not null auto_increment primary key,
    idTorneo int not null references torneo(idTorneo),
    idPremio int null references premio(idPremio),
    nombre varchar(25) not null
);
alter table equipoTorneo auto_increment=1;

create table usuariosEquipo(
	idEquipo int not null references equipoTorneo(idEquipo),
    idUsuario int not null references usuario(idUsuario),
    confirmo bool not null default false
);

create table renta(
	idRenta int not null auto_increment primary key,
    idUsuario int not null references usuario(idUsuario),
    idConsola int not null references consola(idConsola),
    idJuego int null references juego(idJuego),
    fecha date not null,
    hora time not null,
    promocionActiva int not null default 0,
    monedasGanadas int null default 0,
    monedasUsadas int null default 0,
    estatus bool null default 1
);
alter table renta auto_increment=1;

create table accesorio(
	idAccesorio int not null auto_increment primary key,
    nombre varchar(20) not null,
    costo int not null
);
alter table accesorio auto_increment=1;

create table rentaAccesorio(
	idRenta int not null references renta(idRenta),
    idAccesorio int not null references accesorio(idAccesorio),
    nHoras int not null
);

create table dulce(
	idDulce int not null auto_increment primary key,
    nombre varchar(25) not null,
    precio int not null,
    premioMonedas int not null
);
alter table dulce auto_increment=1;

create table rentaDulce(
	idRenta int not null references renta(idRenta),
    idDulce int not null references dulce(idDulce),
    cantidad int not null
);

				-- procedimientos para la tabla usuario --
                
drop procedure if exists get_login;
delimiter $$
create procedure get_login(
_usuario varchar(20),
_contra varchar(100)
)
begin
	select * from usuario where usuario=_usuario and contrasenia=_contra;
end$$

call get_login ('Admin', 'e3afed0047b08059d0fada10f400c1e5');

drop procedure if exists add_usuario;
delimiter $$
create procedure add_usuario(
_id int,
_idRol int,
_nombre varchar(30),
_aPaterno varchar(30),
_aMaterno varchar(30),
_fechaN date,
_genero int,
_telefono varchar(10),
_correo varchar(25),
_usuario varchar(20),
_contra varchar(100),
_rutaFoto varchar(70),
_idUsRef int
)
begin
	declare _monedasRef int default 0;
	set _monedasRef = (select monedasReferencia from usuario limit 1);
	if _id = 0 then		
		insert into usuario(idRol,nombre,aPaterno,aMaterno,fechaNacimiento,genero,telefono,correo,usuario,contrasenia,rutaFoto,idUsuarioReferencia,monedasReferencia)values
		(_idRol,_nombre,_aPaterno,_aMaterno,_fechaN,_genero,_telefono,_correo,_usuario,_contra,_rutaFoto,_idUsRef,_monedasRef);
	else
		update usuario set
			idRol=_idRol,
            nombre=_nombre,
            aPaterno=_aPaterno,
            aMaterno=_aMaterno,
            fechaNacimiento=_fechaN,
            genero=_genero,
            telefono=_telefono,
            correo=_correo,
            usuario=_usuario,
            contrasenia=_contra,
            rutaFoto=_rutaFoto,
            idUsuarioReferencia=_idUsRef,
            monedasReferencia=_monedasRef
		where idUsuario=_id;
	end if;
end$$

drop procedure if exists get_usuarios;
delimiter $$
create procedure get_usuarios()
begin
	select * from usuario where idUsuario > 1;
end $$

drop procedure if exists get_usuariosRef;
delimiter $$
create procedure get_usuariosRef()
begin
	select idUsuario,nombre,aPaterno,usuario from usuario 
	where idRol = 2 and idUsuario not in (select idUsuario from renta where promocionActiva=1);
end $$


drop procedure if exists get_usuario;
delimiter $$
create procedure get_usuario(
in _id int)
begin
	select * from usuario where idUsuario=_id;
end $$

drop procedure if exists delete_usuario;
delimiter $$
create procedure delete_usuario(
in _id int)
begin
	update usuario set
		idUsuarioReferencia = 0
	where idUsuarioReferencia=_id;
	delete from usuario where idUsuario=_id;
end $$

drop procedure if exists get_monedasRef;
delimiter $$
create procedure get_monedasRef()
begin
	select monedasReferencia from usuario limit 1;
end $$

drop procedure if exists updateMonedasRef;
delimiter $$
create procedure updateMonedasRef(
_monedas int
)
begin
	update usuario set
		monedasReferencia=_monedas
	where idUsuario>=1;
end $$

select * from usuario;

					-- procedimientos para la tabla Plataforma --                    
drop procedure if exists get_plataformas;
delimiter $$
create procedure get_plataformas()
begin
	select * from plataforma order by nombre;
end $$

call get_plataformas();

drop procedure if exists get_plataforma;
delimiter $$
create procedure get_plataforma(
_id int
)
begin
	select * from plataforma where idPlataforma=_id;
end $$

drop procedure if exists add_plataforma;
delimiter $$
create procedure add_plataforma(
_id int,
_nombre varchar(25)
)
begin
	if _id = 0 then
		insert into plataforma(nombre) values(_nombre);
    else
		update plataforma set
			nombre=_nombre
		where idPlataforma=_id;
    end if;
end $$

drop procedure if exists delete_plataforma;
delimiter $$
create procedure delete_plataforma(
in _id int)
begin
	delete from plataforma where idPlataforma=_id;
end $$

select * from plataforma

					-- procedimientos para la tabla Consola --                    
drop procedure if exists get_consolas;
delimiter $$
create procedure get_consolas()
begin
	select c.idConsola,c.idPlataforma, p.nombre nombrePla, c.nombre, c.numero, c.seriall, c.costo, c.premioMonedas, c.costoMonedas from consola c
    inner join plataforma p on p.idPlataforma=c.idPlataforma
    order by c.nombre;
end $$

call get_consolas();

/*update consola set
	premioMonedas=5,
	costoMonedas=30
where idConsola=29*/

select * from consola;

drop procedure if exists get_consola;
delimiter $$
create procedure get_consola(
_id int
)
begin
	select * from consola where idConsola=_id;
end $$
call get_consola(6);
select * from consola;

drop procedure if exists add_consola;
delimiter $$
create procedure add_consola(
_id int,
_ids blob,
_nombre varchar(25),
_numero varchar(5),
_seriall varchar(20),
_costo int,
_monedasGanadas int,
_costoMonedas int,
_nIds int
)
begin
	declare i int default 1;
	if _id = 0 then		
		my_loop: LOOP
            insert into consola(idPlataforma,nombre,numero,seriall,costo,premioMonedas,costoMonedas) values(cast(ExtractValue(_ids, '//id[$i]') as signed),_nombre,_numero,_seriall,_costo,_monedasGanadas,_costoMonedas);
			SET i=i+1;
			IF i=_nIds + 1 THEN
				LEAVE my_loop;
			END IF;
		END LOOP my_loop;		
    else
		update consola set
			nombre=_nombre,
            numero=_numero,
            seriall=_seriall,
            costo=_costo,
            premioMonedas=_monedasGanadas,
            costoMonedas=_costoMonedas
		where idConsola=_id;
    end if;
end $$

drop procedure if exists delete_consola;
delimiter $$
create procedure delete_consola(
in _id int)
begin
	delete from consola where idConsola=_id;
end $$

select * from consola;

					-- procedimientos para la tabla juego --                    
drop procedure if exists get_juegos;
delimiter $$
create procedure get_juegos()
begin
	select j.idJuego,j.nombre,j.rutaFoto,c.nombre nombreCon, p.nombre nombrePla from juego j
    inner join consolaJuego cj on cj.idJuego=j.idJuego
    inner join consola c on c.idConsola=cj.idConsola
    inner join plataforma p on p.idPlataforma=c.idPlataforma
    order by j.nombre;
end $$

drop procedure if exists get_juegosCon;
delimiter $$
create procedure get_juegosCon(
_idCon int)
begin
	select j.idJuego,j.nombre,j.rutaFoto,c.nombre nombreCon, p.nombre nombrePla from juego j
    inner join consolaJuego cj on cj.idJuego=j.idJuego
    inner join consola c on c.idConsola=cj.idConsola
    inner join plataforma p on p.idPlataforma=c.idPlataforma
    where c.idConsola=_idCon
    order by j.nombre;
end $$

call get_juegosCon(1);

drop procedure if exists get_juego;
delimiter $$
create procedure get_juego(
_id int
)
begin
	select * from juego where idJuego=_id;
end $$

call get_juego(1);

drop procedure if exists add_juego;
delimiter $$
create procedure add_juego(
_id int,
_ids blob,
_nombre varchar(20),
_foto varchar(70),
_nIds int
)
begin
	declare i int default 1;
	if _id = 0 then
		insert into juego(nombre,rutaFoto)values(_nombre,_foto);
        SELECT max(idJuego) from juego;
		my_loop: LOOP
            insert into consolaJuego(idConsola,idJuego) values(cast(ExtractValue(_ids, '//id[$i]') as signed),(SELECT max(idJuego) from juego));
			SET i=i+1;
			IF i=_nIds + 1 THEN
				LEAVE my_loop;
			END IF;
		END LOOP my_loop;		
    else
		update juego set
			nombre=_nombre,
            rutaFoto=_foto
		where idJuego=_id;
    end if;
end $$

drop procedure if exists delete_juego;
delimiter $$
create procedure delete_juego(
in _id int)
begin
	delete from juego where idJuego=_id;
end $$

select * from juego;
select * from consolaJuego;

						-- procedimientos para la tabla renta --                    
drop procedure if exists get_usuariosRen;
delimiter $$
create procedure get_usuariosRen()
begin
	select idUsuario,nombre,aPaterno,usuario from usuario
    where idUsuario not in (select idUsuario from renta where estatus=1) and idRol = 2;
end $$
                        
drop procedure if exists get_rentas;
delimiter $$
create procedure get_rentas()
begin
	select r.idRenta,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario,c.nombre nombreCon,j.nombre nombreJu,r.fecha,r.hora,r.promocionActiva from renta r
    inner join usuario u on u.idUsuario=r.idUsuario
    inner join consola c on c.idConsola=r.idConsola
    inner join juego j on j.idJuego=r.idJuego
    where r.estatus = 1
    order by fecha,hora;
end $$

call get_rentas();

drop procedure if exists get_rentasHistorico;
delimiter $$
create procedure get_rentasHistorico(_idU int)
begin
	select r.idRenta,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario,c.nombre nombreCon,j.nombre nombreJu,r.fecha,r.hora,r.promocionActiva from renta r
    inner join usuario u on u.idUsuario=r.idUsuario
    inner join consola c on c.idConsola=r.idConsola
    inner join juego j on j.idJuego=r.idJuego
    where r.estatus = 0 and r.idUsuario = _idU
    order by fecha,hora;
end $$

call get_rentasHistorico(2);

drop procedure if exists get_renta;
delimiter $$
create procedure get_renta(
_id int
)
begin
	declare _totalAccesorios int default 0;
    declare _totalDulces int default 0;
    declare _monedasDulces int default 0;
    set _totalAccesorios = (select sum(ra.nHoras*a.costo) from renta r 
    inner join rentaAccesorio ra on ra.idRenta=r.idRenta
    inner join accesorio a on a.idAccesorio=ra.idAccesorio where r.idRenta=_id);    
    set _totalDulces = (select sum(rd.cantidad*d.precio) from renta r 
    inner join rentaDulce rd on rd.idRenta=r.idRenta
    inner join dulce d on d.idDulce=rd.idDulce where r.idRenta=_id);
    set _monedasDulces = (select sum(rd.cantidad*d.premioMonedas) from renta r 
    inner join rentaDulce rd on rd.idRenta=r.idRenta
    inner join dulce d on d.idDulce=rd.idDulce where r.idRenta=_id);
	select r.idRenta,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario,c.nombre nombreCon,r.idConsola,j.nombre nombreJu,r.fecha,r.hora,
    r.promocionActiva,c.costo,c.premioMonedas,c.costoMonedas,u.totalMonedas,_totalAccesorios totalAccesorios,_totalDulces totalDulces,
    _monedasDulces monedasDulces
    from renta r
    inner join usuario u on u.idUsuario=r.idUsuario
    inner join consola c on c.idConsola=r.idConsola
    inner join juego j on j.idJuego=r.idJuego
    where r.idRenta=_id;
end $$

call get_renta(2);

drop procedure if exists add_renta;
delimiter $$
create procedure add_renta(
_id int,
_idUsu int,
_idCon int,
_idJue int,
_fecha date,
_hora time,
_promo int,
_monGan int,
_monUs int
)
begin
	declare i int default 1;
	if _id = 0 then
		insert into renta(idUsuario,idConsola,idJuego,fecha,hora,promocionActiva)values(_idUsu,_idCon,_idJue,_fecha,_hora,_promo);
    else
		update renta set
			estatus=0,
            monedasGanadas=_monGan,
            monedasUsadas=_monUs
		where idRenta=_id;
    end if;
end $$

drop procedure if exists pagar_renta;
delimiter $$
create procedure pagar_renta(
_id int,
_monUs int,
_monGan int,
_met int
)
begin
	declare _idUsu int default 0;
    set _idUsu = (select idUsuario from renta where idRenta=_id);
	if _met = 1 then
		update renta set
			estatus=0,
            monedasGanadas=_monGan
		where idRenta=_id;
        update usuario set
			totalMonedas = totalMonedas + _monGan
		where idUsuario = _idUsu;
	else
		update renta set
			estatus=0,
            monedasGanadas=_monGan,
            monedasUsadas=_monUs
		where idRenta=_id;
        update usuario set
			totalMonedas = (totalMonedas + _monGan) - _monUs
		where idUsuario = _idUsu;
    end if;
end $$

drop procedure if exists get_monedasActuales;
delimiter $$
create procedure get_monedasActuales(
_id int
)
begin	
	select totalMonedas from usuario where idUsuario=_id;
end $$

call get_monedasActuales(2);

drop procedure if exists get_HistoricoCambioMonedas;
delimiter $$
create procedure get_HistoricoCambioMonedas(_idU int)
begin
	select r.idRenta,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario,c.nombre nombreCon,j.nombre nombreJu,r.fecha,r.hora,r.monedasUsadas from renta r
    inner join usuario u on u.idUsuario=r.idUsuario
    inner join consola c on c.idConsola=r.idConsola
    inner join juego j on j.idJuego=r.idJuego
    where r.estatus = 0 and r.idUsuario = _idU and r.monedasUsadas > 0
    order by fecha,hora;
end $$

call get_HistoricoCambioMonedas(2);

					-- procedimientos para la tabla Accesorio --                    
drop procedure if exists get_accesorios;
delimiter $$
create procedure get_accesorios()
begin
	select * from accesorio order by nombre;
end $$

call get_accesorios();

drop procedure if exists get_accesorio;
delimiter $$
create procedure get_accesorio(
_id int
)
begin
	select * from accesorio where idAccesorio=_id;
end $$

call get_accesorio(1);

drop procedure if exists add_accesorio;
delimiter $$
create procedure add_accesorio(
_id int,
_nombre varchar(25),
_costo int
)
begin
	if _id = 0 then
		insert into accesorio(nombre,costo) values(_nombre,_costo);
    else
		update accesorio set
			nombre=_nombre,
            costo=_costo
		where idAccesorio=_id;
    end if;
end $$

drop procedure if exists delete_accesorio;
delimiter $$
create procedure delete_accesorio(
in _id int)
begin
	delete from accesorio where idAccesorio=_id;
end $$

select * from accesorio


					-- procedimientos para la tabla Renta Accesorio --                    
drop procedure if exists get_accesoriosRenta;
delimiter $$
create procedure get_accesoriosRenta()
begin
	select a.nombre,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario, ra.nHoras
    from rentaAccesorio ra
    inner join accesorio a on a.idAccesorio = ra.idAccesorio
    inner join renta r on r.idRenta=ra.idRenta
    inner join usuario u on u.idUsuario = r.idUsuario
    order by nombre;
end $$

call get_accesoriosRenta();

drop procedure if exists get_usuariosRenAcc;
delimiter $$
create procedure get_usuariosRenAcc()
begin
	select r.idRenta,u.idUsuario,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario from usuario u
    inner join renta r on r.idUsuario=u.idUsuario
    where u.idRol = 2  and r.estatus=1;
end $$

call get_usuariosRenAcc();

drop procedure if exists add_accesorioRenta;
delimiter $$
create procedure add_accesorioRenta(
_idUsu int,
_idAcc int,
_nHoras int
)
begin
	insert into rentaAccesorio(idRenta,idAccesorio,nHoras) values(_idUsu,_idAcc,_nHoras);
end $$

select * from rentaAccesorio

					-- procedimientos para la tabla Dulce --                    
drop procedure if exists get_dulces;
delimiter $$
create procedure get_dulces()
begin
	select * from dulce order by nombre;
end $$

call get_dulces();

drop procedure if exists get_dulce;
delimiter $$
create procedure get_dulce(
_id int
)
begin
	select * from dulce where idDulce=_id;
end $$

call get_dulce(1);

drop procedure if exists add_dulce;
delimiter $$
create procedure add_dulce(
_id int,
_nombre varchar(25),
_costo int,
_monDad int
)
begin
	if _id = 0 then
		insert into dulce(nombre,precio,premioMonedas) values(_nombre,_costo,_monDad);
    else
		update dulce set
			nombre=_nombre,
            precio=_costo,
            premioMonedas=_monDad
		where idDulce=_id;
    end if;
end $$

drop procedure if exists delete_dulce;
delimiter $$
create procedure delete_dulce(
in _id int)
begin
	delete from dulce where idDulce=_id;
end $$

select * from accesorio


					-- procedimientos para la tabla Venta Dulce --                    
drop procedure if exists get_DulcesVenta;
delimiter $$
create procedure get_DulcesVenta()
begin
	select d.nombre,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario, rd.cantidad
    from rentadulce rd
    inner join dulce d on d.idDulce= rd.idDulce
    inner join renta r on r.idRenta=rd.idRenta
    inner join usuario u on u.idUsuario = r.idUsuario
    order by nombre;
end $$

call get_DulcesVenta();

drop procedure if exists add_ventaDulce;
delimiter $$
create procedure add_ventaDulce(
_idUsu int,
_idDul int,
_cant int
)
begin
	insert into rentadulce(idRenta,idDulce,cantidad) values(_idUsu,_idDul,_cant);
end $$

select * from rentadulce



						-- procedimientos para la tabla torneo --                                 
drop procedure if exists get_Torneos;
delimiter $$
create procedure get_Torneos()
begin
	update torneo set 
    estatus=2
    where fecha <= CURDATE() and hora <= curTime();
	select t.idTorneo,t.titulo, c.nombre nombreCon, j.nombre nombreJue,t.fecha,t.hora,t.modalidad,t.totalIntegrantesEquipo,t.forma,t.maximoEquipos,
    t.descripcion,t.estatus,t.costo from torneo t
    inner join consola c on c.idConsola=t.idConsola
    inner join juego j on j.idJuego=t.idJuego 
    order by fecha,hora;
end $$

call get_Torneos();

drop procedure if exists get_Torneo;
delimiter $$
create procedure get_Torneo(_id int)
begin
	select t.idTorneo,t.titulo, c.nombre nombreCon, j.nombre nombreJue,t.fecha,t.hora,t.modalidad,t.totalIntegrantesEquipo,t.forma,t.maximoEquipos,
    t.descripcion,t.estatus,t.costo from torneo t
    inner join consola c on c.idConsola=t.idConsola
    inner join juego j on j.idJuego=t.idJuego 
    where t.idTorneo=_id
    order by fecha,hora;
end $$

call get_Torneo(3);

drop procedure if exists add_torneo;
delimiter $$
create procedure add_torneo(
_id int,
_idCon int,
_idJue int,
_titulo varchar(30),
_fecha date,
_hora time,
_modalidad int,
_totalInt int,
_forma int,
_maxJug int,
_descripcion varchar(150),
_costo int
)
begin
	if _id = 0 then
		insert into torneo(idConsola,idJuego,titulo,fecha,hora,modalidad,totalIntegrantesEquipo,forma,maximoEquipos,descripcion,costo)values
        (_idCon,_idJue,_titulo,_fecha,_hora,_modalidad,_totalInt,_forma,_maxJug,_descripcion,_costo);
    else
		update torneo set
            idConsola=_idCon,
            idJuego=_idJue,
            titulo=_titulo,
            fecha=_fecha,
            hora=_hora,
            modalidad=_modalidad,
            totalIntegrantesEquipo=_totalInt,
            forma=_forma,
            maximoEquipos=_maxJug,
            descripcion=_descripcion,
            costo=_costo
		where idTorneo=_id;
    end if;
end $$

drop procedure if exists cancelar_torneo;
delimiter $$
create procedure cancelar_torneo(
_id int
)
begin
	update torneo set
		estatus=4
	where idTorneo=_id;
end $$

drop procedure if exists finalizar_torneo;
delimiter $$
create procedure finalizar_torneo(
_id int
)
begin
	update torneo set
		estatus=3
	where idTorneo=_id;
end $$

drop procedure if exists get_equiposPremios;
delimiter $$
create procedure get_equiposPremios(_idTorneo int)
begin
	select et.idEquipo,et.nombre from equipotorneo et
    where et.idTorneo = _idTorneo;
end $$

call get_equiposPremios(2);

drop procedure if exists get_TorneosRegistro;
delimiter $$
create procedure get_TorneosRegistro(_idUsuario int)
begin
	select t.idTorneo,t.titulo, c.nombre nombreCon, j.nombre nombreJue,t.fecha,t.hora,t.modalidad,t.totalIntegrantesEquipo,t.forma,t.maximoEquipos,
    t.descripcion,t.estatus,t.costo,ue.idUsuario from torneo t
    left join equipoTorneo et on et.idTorneo=t.idTorneo
    left join usuariosEquipo ue on ue.idEquipo=et.idEquipo
    inner join consola c on c.idConsola=t.idConsola
    inner join juego j on j.idJuego=t.idJuego      
    where t.estatus=1
    order by fecha,hora;
end $$

call get_TorneosRegistro(2);

drop procedure if exists get_UsuariosTorneosRegistro;
delimiter $$
create procedure get_UsuariosTorneosRegistro(_idUsuario int)
begin
	select u.idUsuario,concat(u.nombre,' ',u.aPaterno,' (',u.usuario,')') usuario from usuario u
    where u.idUsuario not in(_idUsuario) and idRol=2;
end

call get_UsuariosTorneosRegistro(2);

drop procedure if exists add_equipoTorneo;
delimiter $$
create procedure add_equipoTorneo(
_idTorneo int,
_nombreEq varchar(25),
_ids blob,
_nIds int,
_idUsu int
)
begin
	declare i int default 1;
    declare _idEquipo int default 0;
	insert into equipoTorneo(idTorneo,nombre)values(_idTorneo,_nombreEq);
    set _idEquipo = (SELECT max(idEquipo) from equipoTorneo);
    insert into usuariosEquipo(idEquipo,idUsuario,confirmo) values(_idEquipo,_idUsu,1);
    if _nIds > 0 then
		my_loop: LOOP
			insert into usuariosEquipo(idEquipo,idUsuario) values(_idEquipo,cast(ExtractValue(_ids, '//id[$i]') as signed));
			SET i=i+1;
			IF i=_nIds + 1 THEN
				LEAVE my_loop;
			END IF;
		END LOOP my_loop;
    end if;
end $$

drop procedure if exists get_MisTorneos;
delimiter $$
create procedure get_MisTorneos(_idUsuario int)
begin
	select t.idTorneo,t.titulo, c.nombre nombreCon, j.nombre nombreJue,t.fecha,t.hora,t.modalidad,t.totalIntegrantesEquipo,t.forma,t.maximoEquipos,
    t.descripcion,t.estatus,t.costo,ue.idUsuario from torneo t
    left join equipoTorneo et on et.idTorneo=t.idTorneo
    left join usuariosEquipo ue on ue.idEquipo=et.idEquipo
    inner join consola c on c.idConsola=t.idConsola
    inner join juego j on j.idJuego=t.idJuego      
    where t.estatus=1 and ue.confirmo=1
    order by fecha,hora;
end $$

call get_MisTorneos(2);

drop procedure if exists get_invitaciones;
delimiter $$
create procedure get_invitaciones(_idUsuario int)
begin
	select ue.idEquipo,et.nombre equipo,t.titulo,t.fecha,t.hora from usuariosEquipo ue
    inner join equipoTorneo et on et.idEquipo=ue.idEquipo
    inner join torneo t on t.idTorneo=et.idTorneo
    where ue.confirmo=0 and ue.idUsuario in (_idUsuario);
end $$

call get_invitaciones(2);

drop procedure if exists aceptar_invitacion;
delimiter $$
create procedure aceptar_invitacion(
_idEquipo int,
_idUsu int
)
begin
	update usuariosEquipo set
		confirmo=1
	where idEquipo=_idEquipo and idUsuario=_idUsu;
end $$

update usuariosEquipo set
confirmo=0
where idEquipo=1 and idUsuario=2;


					-- procedimientos para la tabla Premios --
drop procedure if exists get_TorneosPremios;
delimiter $$
create procedure get_TorneosPremios()
begin
	select t.idTorneo,t.titulo, c.nombre nombreCon, j.nombre nombreJue,t.fecha,t.hora,t.modalidad,t.totalIntegrantesEquipo,t.forma,t.maximoEquipos,
    t.descripcion,t.estatus,t.costo from torneo t
    inner join consola c on c.idConsola=t.idConsola
    inner join juego j on j.idJuego=t.idJuego
    where t.idTorneo not in (select idTorneo from premio) and t.estatus=1
    order by fecha,hora;
end $$

call get_TorneosPremios();

drop procedure if exists get_premios;
delimiter $$
create procedure get_premios()
begin
	select p.idPremio,p.idTorneo,t.titulo,p.posicion,p.premio from premio p
    inner join torneo t on t.idTorneo = p.idTorneo
    order by t.idTorneo;
end $$

call get_premios();

drop procedure if exists add_premio;
delimiter $$
create procedure add_premio(
_idTorneo int,
_premio1 varchar(100),
_premio2 varchar(100),
_premio3 varchar(100)
)
begin
	insert into premio(idTorneo,posicion,premio) values(_idTorneo,1,_premio1);
    insert into premio(idTorneo,posicion,premio) values(_idTorneo,2,_premio2);
    insert into premio(idTorneo,posicion,premio) values(_idTorneo,3,_premio3);
end $$

select * from premio
